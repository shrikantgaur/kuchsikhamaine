<?php

/* Template Name: No Sidebar Template */

/* 
 * Uses the same content structure as the singular.php template,
 * but with the sidebar hidden and a class added to the body.
 */

get_template_part( 'singular' );